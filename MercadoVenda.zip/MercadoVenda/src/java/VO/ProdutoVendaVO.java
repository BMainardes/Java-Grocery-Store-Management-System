/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VO;

public class ProdutoVendaVO {
    private int venda_produto;
    private int pordutoid;
    private int quantidade;
    private int vendaid;
    private String nome;
    private double preco;
    
    
    public int getVenda_produto() {
        return venda_produto;
    }

    public void setVenda_produto(int venda_produto) {
        this.venda_produto = venda_produto;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getVendaid() {
        return vendaid;
    }

    public void setVendaid(int vendaid) {
        this.vendaid = vendaid;
    }

    public int getPordutoid() {
        return pordutoid;
    }

    public void setPordutoid(int pordutoid) {
        this.pordutoid = pordutoid;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

   
}