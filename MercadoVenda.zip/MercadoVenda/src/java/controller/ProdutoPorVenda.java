package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import DAO.ProdutoVendaDAO;
import VO.ProdutoVendaVO;

public class ProdutoPorVenda extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
            int vendaId = 0;
            int produtoid = 0;
            int quantidade = 0;

        try (PrintWriter out = response.getWriter()) {
            vendaId = Integer.parseInt(request.getParameter("vendaId"));
            produtoid = Integer.parseInt(request.getParameter("produtoid"));
            quantidade = Integer.parseInt(request.getParameter("quantidade"));

            ProdutoVendaDAO dao = new ProdutoVendaDAO();
            ProdutoVendaVO item = new ProdutoVendaVO();
            item.setVendaid(vendaId);
            item.setPordutoid(produtoid);
            item.setQuantidade(quantidade);

            // Adicionar item de venda ao banco de dados
            dao.addItemVenda(item, vendaId);

            
            // Enviar a lista atualizada para a página JSP
            request.setAttribute("lista", dao.listar(vendaId));
            request.setAttribute("vendaId", vendaId);
            
            // Redirecionar para a página JSP para exibir os itens da venda
            RequestDispatcher rd = request.getRequestDispatcher("ProdutoVendaform.jsp");
            rd.forward(request, response);
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            response.getWriter().println("Erro ao adicionar item de venda: " + ex.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
