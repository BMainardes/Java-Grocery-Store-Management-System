package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DAO.vendaDAO;
import VO.vendaVO;

public class venda extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (PrintWriter out = response.getWriter()) {
            int id = Integer.parseInt(request.getParameter("vendedor"));

            vendaVO venda = new vendaVO();
            venda.setVendedorId(id);
            venda.setCpf("000000000");
            venda.setValorTotal(0.00);

            vendaDAO vend = new vendaDAO();
            int vendaId = vend.gravar(venda);
            if (vendaId != -1) {
                response.sendRedirect("ProdutoVendaform.jsp?vendaId=" + vendaId);
            } else {
                response.sendRedirect("NewVenda.html");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
