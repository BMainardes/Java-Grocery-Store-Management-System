package controller;

import DAO.vendaDAO;
import VO.vendaVO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FinalVenda extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        int id = -1;
        String cpf = null;
        double total = 0.0;

        try {
            id = Integer.parseInt(request.getParameter("vendaId"));
            cpf = request.getParameter("cpf");
            total = Double.parseDouble(request.getParameter("totalVenda"));
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Parâmetros inválidos");
            return;
        }

        vendaVO venda = new vendaVO();
        venda.setCpf(cpf);
        venda.setValorTotal(total);

        vendaDAO vend = new vendaDAO();
        int vendaId = vend.atualizar(venda, id);

        if (vendaId != -1) {
            response.sendRedirect("notaFisc.jsp?vendaId=" + id); // Passando o ID da venda na URL
        } else {
            response.sendRedirect("NewVenda.html");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Finaliza uma venda, atualizando os dados no banco de dados.";
    }
}
