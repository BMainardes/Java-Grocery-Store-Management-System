package DAO;

import conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import VO.vendaVO;

public class vendaDAO {

    // Método para verificar se o ID do vendedor existe
    private boolean vendedorExiste(int vendedorId) {
        String sql = "SELECT COUNT(*) FROM vendedor WHERE id = ?";
        try (Connection con = new conexao().estabeleceConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, vendedorId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao verificar vendedor: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // Método para verificar se o ID da venda existe
    private boolean vendaExiste(int vendaId) {
        String sql = "SELECT COUNT(*) FROM vendas WHERE id = ?";
        try (Connection con = new conexao().estabeleceConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, vendaId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao verificar venda: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    public int gravar(vendaVO v) {
        if (!vendedorExiste(v.getVendedorId())) {
            System.out.println("ID do vendedor não existe: " + v.getVendedorId());
            return -1;
        }
        String sql = "INSERT INTO vendas (vendedor_id, cpf, valor_total) VALUES (?, ?, ?)";
        try (Connection con = new conexao().estabeleceConexao();
             PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, v.getVendedorId());
            ps.setString(2, v.getCpf());
            ps.setDouble(3, v.getValorTotal());

            int rowsInserted = ps.executeUpdate();
            if (rowsInserted > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        int vendaId = rs.getInt(1);
                        return vendaId;
                    }
                }
            }
            return -1;
        } catch (SQLException e) {
            System.out.println("Erro ao inserir venda: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
    }
    
    public int atualizar(vendaVO v, int id) {
        // Verifica se a venda existe antes de tentar atualizar
        if (!vendaExiste(id)) {
            System.out.println("Venda ID não existe: " + id);
            return -1;
        }

        String sql = "UPDATE vendas SET cpf = ?, valor_total = ? WHERE id = ?";
        try (Connection con = new conexao().estabeleceConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, v.getCpf());
            ps.setDouble(2, v.getValorTotal());
            ps.setInt(3, id);

            System.out.println("SQL de atualização: " + ps.toString()); // Log para depuração

            int rowsUpdated = ps.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Venda atualizada com sucesso! ID: " + id);
                return id;
            } else {
                System.out.println("Nenhuma venda foi atualizada para ID: " + id);
                return -1;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar venda: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
    }
}
