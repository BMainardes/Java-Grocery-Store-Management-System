package DAO;

import conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import VO.ProdutoVendaVO;

public class ProdutoVendaDAO {

    public ArrayList<ProdutoVendaVO> listar(int vendaId) {
        PreparedStatement ps;
        ResultSet rs;
        Connection con;

        try {
            con = new conexao().estabeleceConexao();
            if (con != null) {
                String sql = "SELECT vp.venda_id,vp.produto_id,vp.quantidade,p.id AS id_produto,p.nome AS nome_produto,p.preco FROM venda_produto vp JOIN produtos p ON vp.produto_id = p.id WHERE vp.venda_id = ?";
                ps = con.prepareStatement(sql);
                ps.setInt(1, vendaId);
                rs = ps.executeQuery();
                ArrayList<ProdutoVendaVO> lista = new ArrayList<>();
                while (rs.next()) {
                    ProdutoVendaVO c = new ProdutoVendaVO();
                    c.setPordutoid(rs.getInt("produto_id"));
                    c.setQuantidade(rs.getInt("quantidade"));
                    c.setVendaid(rs.getInt("venda_id"));
                    c.setNome(rs.getString("nome_produto"));
                    c.setPreco(rs.getDouble("preco"));
                    lista.add(c);
                }
                con.close();
                return lista;
            } else {
                return null;
            }
        } catch (SQLException erro) {
            System.err.print("Exceção gerada ao tentar buscar os dados: " + erro.getMessage());
            return null;
        }
    }

    public int addItemVenda(ProdutoVendaVO item, int vendaId) throws SQLException {
        String sql = "INSERT INTO venda_produto (venda_id, produto_id, quantidade) VALUES (?, ?, ?)";
        try (Connection con = new conexao().estabeleceConexao();
             PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, vendaId);
            ps.setInt(2, item.getPordutoid());
            ps.setInt(3, item.getQuantidade());

            int rowsInserted = ps.executeUpdate();
            if (rowsInserted > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }
                }
            }
            return -1;
        } catch (SQLException e) {
            System.out.println("Erro ao inserir venda: " + e.getMessage());
            e.printStackTrace();
            return -1;
        }
    }
}
