/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import VO.vendVO;

/**
 *
 * @author USER
 */
public class vendDAO {
    public String gravar(vendVO v) {
        try {
            Connection con = new conexao().estabeleceConexao();
            PreparedStatement ps;
            String sql = "INSERT INTO vendedor (nome, cpf, telefone, email) VALUES (?, ?, ?, ?)";
            ps = con.prepareStatement(sql);
            
            ps.setString(1, v.getNome());
            ps.setString(2, v.getCpf());
            ps.setString(3, v.getTelefone());
            ps.setString(4, v.getEmail());
            
            int rowsInserted = ps.executeUpdate();
            con.close(); // Fechando a conexão depois de usar
            
            if (rowsInserted > 0) {
                return null; // Sucesso
            } else {
                return "Erro ao inserir vendedor.";
            }
        } catch (SQLException e) {
            if (e.getSQLState().equals("23000")) {
                if (e.getMessage().contains("cpf")) {
                    return "CPF já cadastrado.";
                } else if (e.getMessage().contains("email")) {
                    return "Email já cadastrado.";
                }
            }
            return "Erro: " + e.getMessage();
        }
    }
}